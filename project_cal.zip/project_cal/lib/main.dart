import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

void main() => runApp(CalculatorApp());

class CalculatorApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false, // Remove the debug banner
      title: 'Calculator',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: CalculatorHomePage(),
    );
  }
}

class CalculatorHomePage extends StatefulWidget {
  @override
  _CalculatorHomePageState createState() => _CalculatorHomePageState();
}

class _CalculatorHomePageState extends State<CalculatorHomePage> {
  String _display = '0';
  double? _firstOperand;
  double? _secondOperand;
  String? _operator;
  bool _isError = false;

  @override
  void initState() {
    super.initState();
    _loadState();
  }

  Future<void> _loadState() async {
    final prefs = await SharedPreferences.getInstance();
    setState(() {
      _display = prefs.getString('display') ?? '0';
    });
  }

  Future<void> _saveState() async {
    final prefs = await SharedPreferences.getInstance();
    prefs.setString('display', _display);
  }

  void _inputDigit(String digit) {
    if (_isError) {
      _clearAll();
    }
    setState(() {
      if (_display == '0') {
        _display = digit;
      } else if (_display.length < 8) {
        _display += digit;
      } else {
        _display = 'OVERFLOW';
        _isError = true;
      }
      _saveState();
    });
  }

  void _inputDecimal() {
    if (_isError) {
      _clearAll();
    }
    setState(() {
      if (!_display.contains('.')) {
        _display += '.';
      }
      _saveState();
    });
  }

  void _setOperator(String operator) {
    if (_isError) {
      _clearAll();
    }
    setState(() {
      _firstOperand = double.tryParse(_display);
      _operator = operator;
      _display = '0';
      _saveState();
    });
  }

  void _calculate() {
    if (_isError) {
      _clearAll();
    }
    setState(() {
      _secondOperand = double.tryParse(_display);
      if (_firstOperand != null && _secondOperand != null && _operator != null) {
        switch (_operator) {
          case '+':
            _display = (_firstOperand! + _secondOperand!).toString();
            break;
          case '-':
            _display = (_firstOperand! - _secondOperand!).toString();
            break;
          case '*':
            _display = (_firstOperand! * _secondOperand!).toString();
            break;
          case '/':
            if (_secondOperand == 0) {
              _display = 'ERROR';
              _isError = true;
            } else {
              _display = (_firstOperand! / _secondOperand!).toString();
            }
            break;
        }
        if (_display.length > 8) {
          _display = 'OVERFLOW';
          _isError = true;
        } else {
          _firstOperand = null;
          _operator = null;
        }
      }
      _saveState();
    });
  }

  void _clearAll() {
    setState(() {
      _display = '0';
      _firstOperand = null;
      _secondOperand = null;
      _operator = null;
      _isError = false;
      _saveState();
    });
  }

  void _clearEntry() {
    setState(() {
      _display = '0';
      _saveState();
    });
  }

  void _backspace() {
    if (_isError) {
      _clearAll();
    }
    setState(() {
      if (_display.length > 1) {
        _display = _display.substring(0, _display.length - 1);
      } else {
        _display = '0';
      }
      _saveState();
    });
  }

  Widget _buildButton(String label, Color backgroundColor, Color textColor, Function() onPressed) {
    return Expanded(
      child: Container(
        margin: EdgeInsets.all(4.0),
        child: OutlinedButton(
          style: OutlinedButton.styleFrom(
            backgroundColor: backgroundColor,
            side: BorderSide(color: Colors.white, width: 2), // White border with width
            padding: EdgeInsets.all(24),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(0), // Square shape
            ),
          ),
          onPressed: onPressed,
          child: Text(
            label,
            style: TextStyle(fontSize: 24, color: textColor),
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black, // Change background color to black
      body: Column(
        children: <Widget>[
          Expanded(
            child: Container(
              alignment: Alignment.bottomRight,
              padding: EdgeInsets.symmetric(horizontal: 24, vertical: 32),
              child: Text(
                _display,
                style: TextStyle(fontSize: 48, fontWeight: FontWeight.bold, color: Colors.white), // Text color
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
              ),
            ),
          ),
          Row(
            children: <Widget>[
              _buildButton('7', Colors.black87, Colors.white, () => _inputDigit('7')),
              _buildButton('8', Colors.black87, Colors.white, () => _inputDigit('8')),
              _buildButton('9', Colors.black87, Colors.white, () => _inputDigit('9')),
              _buildButton('/', Colors.black87, Colors.white, () => _setOperator('/')),
            ],
          ),
          Row(
            children: <Widget>[
              _buildButton('4', Colors.black87, Colors.white, () => _inputDigit('4')),
              _buildButton('5', Colors.black87, Colors.white, () => _inputDigit('5')),
              _buildButton('6', Colors.black87, Colors.white, () => _inputDigit('6')),
              _buildButton('*', Colors.black87, Colors.white, () => _setOperator('*')),
            ],
          ),
          Row(
            children: <Widget>[
              _buildButton('1', Colors.black87, Colors.white, () => _inputDigit('1')),
              _buildButton('2', Colors.black87, Colors.white, () => _inputDigit('2')),
              _buildButton('3', Colors.black87, Colors.white, () => _inputDigit('3')),
              _buildButton('-', Colors.black87, Colors.white, () => _setOperator('-')),
            ],
          ),
          Row(
            children: <Widget>[
              _buildButton('AC', Colors.black87, Colors.white, _clearEntry),
              _buildButton('0', Colors.black87, Colors.white, () => _inputDigit('0')),
              _buildButton('C', Colors.black87, Colors.white, _clearAll),
              _buildButton('+', Colors.black87, Colors.white, () => _setOperator('+')),
            ],
          ),
          Row(
            children: <Widget>[
              _buildButton('.', Colors.orangeAccent, Colors.white, _inputDecimal),
              _buildButton('=', Colors.orangeAccent, Colors.white, _calculate),
            ],
          ),
        ],
      ),
    );
  }
}
